document.getElementById('area6').innerHTML = "OK";
