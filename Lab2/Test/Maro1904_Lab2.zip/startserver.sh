#!/bin/bash
echo "Starting up the server..."
./server
